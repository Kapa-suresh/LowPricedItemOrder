import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(
        plugin = {"pretty","html:target/cucumber-html-report.html", "json:target/cucumber-json-report.json"},
        features = "src/test/Features/",
        publish = true,
        monochrome=true
        //tags="@TC-001"

)
public class CucumberRunner {
}
