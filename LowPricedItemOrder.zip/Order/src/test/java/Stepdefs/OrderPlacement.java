package Stepdefs;

import Pages.*;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;
import io.cucumber.datatable.DataTable;

public class OrderPlacement {

    HomePage homePage;
    AddressPage addressPage;
    PaymentPage paymentPage;
    SearchResults searchResultsPage;
    ShippingPage shippingPage;
    SignInPage signInPage;
    SummaryPage summaryPage;

    @Given("user is on automation practice home page")
    public void user_is_on_automation_practice_home_page() {

        homePage= new HomePage();
        homePage.navigateToHomePage();


    }

    @When("user searches with a keyword {string}")
    public void userSearchesWithAKeyword(String searchText) {
        homePage.searchItem(searchText);
        Assert.assertTrue("No results found to proceed further.",homePage.verifySearchResults());//Asserting on search results to handle the testcase execution in better way.
    }

    @Then("selects lowest cost item from search results")
    public void selectsLowestCostItemFromSearchResults() {
        searchResultsPage= new SearchResults();
        searchResultsPage.sortInAscendingOrder();
    }

    @And("adds it to cart")
    public void addsItToCart() {
        searchResultsPage.addLowestPricedItemtoCart();
    }

    @And("proceeds to checkout")
    public void proceedsToCheckout() throws InterruptedException {
        searchResultsPage.proceedToCheckOut();
    }


    @And("Verifies summary screen and proceeds to checkout")
    public void verifiesSummaryScreenAndProceedsToCheckout() {
        summaryPage= new SummaryPage();
        summaryPage.proceedToCheckOutInSummary();
    }

    @And("adds new address")
    public void addsNewAddress() {
        addressPage= new AddressPage();
        addressPage.processAddress();
    }

    @And("verified Shipping")
    public void verifiedShipping() {
        shippingPage = new ShippingPage();
        shippingPage.agreeToTerms();
        shippingPage.processCarrier();
    }

    @And("Verifies user is signed in if not use below credentials")
    public void verifiesUserIsSignedInIfNotUseBelowCredentials(DataTable table) {
        signInPage= new SignInPage();
        signInPage.UserSignInProcess(table.row(0).get(0).toString(),table.row(0).get(1).toString());
    }

    @And("does a {string} payment")
    public void doesAPayment(String paymentType) {
        paymentPage= new PaymentPage();
        paymentPage.selectPaymentTypeAndConfirmOrder(paymentType);
    }
}
