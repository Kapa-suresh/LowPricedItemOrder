package Pages;

import Utilities.CommonMethods;
import java.io.FileInputStream;
import java.io.InputStream;

public class HomePage extends CommonMethods {

    static String searchbarID="search_query_top";
    static String searchBtnName="submit_search";
    static String srStgXpath="//span[contains(text(),'results have been found. ')]";

    public void navigateToHomePage()
    {
        try
        {
            InputStream ip= new FileInputStream(propFileName);
            prop.load(ip);
            driver.get(prop.getProperty("instance.URL")); // Navigating to specified URL

        }
        catch(Exception ex)
        {

        }
    }

    public void searchItem(String itemTxt) // Searching an item
    {
        findElement("ID",searchbarID).sendKeys(itemTxt);
        findElement("Name",searchBtnName).click();
        explicitWait(findElement("Xpath",srStgXpath));

    }
    public boolean verifySearchResults() // Validating results, if there are no results found returning false.
    {
        String resCount=findElement("Xpath",srStgXpath).getText();
        String[] eachword= resCount.split(" ");
        int searchCount= Integer.parseInt(eachword[0]);

        if(searchCount>0)
        {
        return true;
        }
        else
        {
            return false;
        }

    }



}
