package Pages;

import Utilities.CommonMethods;

public class ShippingPage extends CommonMethods {

    String processCarrierXpath="//button[@name='processCarrier']";
    String termsCheckboxId="cgv";

    public void processCarrier()
    {
        findElement("Xpath",processCarrierXpath).click();
    }
    public void agreeToTerms()
    {
        if(!(findElement("ID", termsCheckboxId).isSelected()))
        {
            findElement("ID", termsCheckboxId).click();
        }
    }

}
