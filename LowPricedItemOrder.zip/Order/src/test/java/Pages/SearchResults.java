package Pages;

import Utilities.CommonMethods;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class SearchResults extends CommonMethods {

     String sortDrpdwnID="selectProductSort";
     double lowsetPricedItem=0.00;
     String proceedToCheckoutXpath="//div[@id='layer_cart' and contains(@style,'display: block;')]//a[@title='Proceed to checkout']";
     String addToCartXpath="//span[contains(.,'$"+"%.2f"+"')]/parent::div/following-sibling::div//a[contains(@title,'Add to cart')]";
     String allItemsPricesXpath="//div[@class='right-block']//span[@class='price product-price']";
     String lowestPricedItemXpath="//div[@class='right-block']//span[contains(text(),'$"+"%.2f"+"')]";



    public void sortInAscendingOrder()// Sorting in ascending order to find the using sort dropdown
    {

        selectAnElementByText(findElement("ID",sortDrpdwnID),"Price: Lowest first");
    }

    /*sort using dropdown is sorting on actual price but not on discounted price, so we developed a method 'findListPriceItem' to find out
            list priced item from results*/
    public void addLowestPricedItemtoCart()
    {
        Actions a= new Actions(driver);
        explicitWait(findListPricedItem());
        a.moveToElement(findListPricedItem()).perform();
        addToCartXpath= String.format(addToCartXpath, lowsetPricedItem);
        explicitWait(findElement("Xpath",addToCartXpath));
        findElement("Xpath",addToCartXpath).click();

    }

    public void proceedToCheckOut() throws InterruptedException {

        explicitWait(findElement("xpath",proceedToCheckoutXpath));
        findElement("Xpath",proceedToCheckoutXpath).click();

    }

    public WebElement findListPricedItem()
    {

        List<WebElement> Allproducts=driver.findElements(By.xpath(allItemsPricesXpath));//Getting prices of all items dispalyed
        List<Double> costs= new ArrayList<>();
        for (WebElement e:Allproducts
             ) {
            String cost=e.getText();
            cost=cost.replace("$","");
            costs.add(Double.parseDouble(cost));   // adding each cost to list, so that we can easily find out low price value
        }

        lowsetPricedItem = Collections.min(costs);// finding low price element in the list
        lowestPricedItemXpath=String.format(lowestPricedItemXpath,lowsetPricedItem);
        return findElement("xpath",lowestPricedItemXpath);
    }

}
