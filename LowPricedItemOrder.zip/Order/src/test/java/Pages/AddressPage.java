package Pages;

import Utilities.CommonMethods;

public class AddressPage extends CommonMethods {

    String processAddressXpath="//button[@name='processAddress']";

    public void processAddress()
    {
        findElement("Xpath",processAddressXpath).click();
    }


}
