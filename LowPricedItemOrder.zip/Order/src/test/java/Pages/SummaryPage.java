package Pages;

import Utilities.CommonMethods;

public class SummaryPage extends CommonMethods {

    String proceedToCheckOutXpath="//p[@class='cart_navigation clearfix']//a[@title='Proceed to checkout']";

    public void proceedToCheckOutInSummary()
    {
        findElement("Xpath",proceedToCheckOutXpath).click();
    }

}
