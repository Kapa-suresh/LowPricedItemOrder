package Pages;

import Utilities.CommonMethods;
import org.junit.Assert;

public class SignInPage extends CommonMethods {
    String emailID="email";
    String passwordID="passwd";
    String submitBtnID="SubmitLogin";

    public void SignIn(String username, String password)
    {
        EnterUserName(username);
        EnterPassword(password);
        ClickSignInButton();

    }
    public void EnterUserName(String userName)
    {
        enterText("ID",emailID,userName);
    }
    public void EnterPassword(String password)
    {
        enterText("ID",passwordID,password);
    }
    public void ClickSignInButton()
    {
        findElement("ID",submitBtnID).click();
    }

    public void UserSignInProcess(String userName, String password)
    {
        try {
            Assert.assertTrue(findElement("ID",submitBtnID).isDisplayed());// Verifying that sign-in button is displayed or not, if yes we proceed with sign in otherwise continue further
            SignIn(userName,password);
        }
        catch(AssertionError ex)// when assertion for sign-in is failed, we catch it here and continue further, instead of stopping TC execution
        {
            System.out.println("User is signed in. Hence continue with address section");
        }
    }

}
