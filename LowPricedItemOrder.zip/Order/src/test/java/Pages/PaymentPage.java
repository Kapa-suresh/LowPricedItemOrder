package Pages;

import Utilities.CommonMethods;
import Utilities.DriverManagement;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;

public class PaymentPage extends CommonMethods {

    String chequeXpath = "//div[@id='HOOK_PAYMENT']//a[contains(@title,'Pay by check')]";
    String confirmButtonXpath = "//button[contains(.,'I confirm my order')]";

    public void selectPaymentTypeAndConfirmOrder(String type)
    {


        if(type.equalsIgnoreCase("Cheque"))
        {

            Actions a = new Actions(driver);
            a.moveToElement(findElement("Xpath",chequeXpath)).perform();
            findElement("Xpath",chequeXpath).click();
            explicitWait(findElement("xpath",confirmButtonXpath));
            findElement("xpath",confirmButtonXpath).click();

        }
        else
        {
            //code for wire payment
        }
    }
}
