package Utilities;

import java.util.Properties;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;


public class CommonMethods {
	protected static WebDriver driver;
	DriverManagement driverManagement;
	public static String DataFolderPath=System.getProperty("user.dir")+"/Data/";
	public static String propFileName=DataFolderPath+"GlobalProperties.properties";
	public static Properties prop= new Properties();

	public CommonMethods()
	{
		driverManagement = new DriverManagement();
		driver= driverManagement.getDriver();// initializing driver object
	}

	public static WebElement explicitWait(WebElement ele)
	{
		try {
			WebDriverWait wait = new WebDriverWait(driver, 60);
			wait.until(ExpectedConditions.visibilityOf(ele));
		} catch (Exception e) {

			e.printStackTrace();
			
		}
		return ele;
	}


	public static void selectAnElementByText(WebElement e, String dropDownValue)
	{
		Select s= new Select(e);
		s.selectByVisibleText(dropDownValue);
	}

	public  static void enterText(String locatorType, String locator, String Text) {
		WebElement wb=findElement(locatorType,locator);
		wb.clear();
		wb.sendKeys(Text);

	}

	public static WebElement findElement(String locatorType,String locator)
	{
		WebElement element = null;
		if (locatorType.equalsIgnoreCase("class")){
			element = driver.findElement(By.className(locator));
		}else if (locatorType.equalsIgnoreCase("id")){
			element = driver.findElement(By.id(locator));
		}else if (locatorType.equalsIgnoreCase("css")){
			element = driver.findElement(By.cssSelector(locator));
		}else if (locatorType.equalsIgnoreCase("linkText")){
			element = driver.findElement(By.linkText(locator));
		}else if (locatorType.equalsIgnoreCase("partialLinkText")){
			element = driver.findElement(By.partialLinkText(locator));
		}else if (locatorType.equalsIgnoreCase("name")){
			element = driver.findElement(By.name(locator));
		}else if (locatorType.equalsIgnoreCase("xpath")){
			element = driver.findElement(By.xpath(locator));
		}else if (locatorType.equalsIgnoreCase("tagName")){
			element = driver.findElement(By.tagName(locator));
		}else{
			System.out.println("Can not find element using locator - " + locator );
			throw new WebDriverException("Incorrect Locator Format");
		}
		return element;


	}
	
}
