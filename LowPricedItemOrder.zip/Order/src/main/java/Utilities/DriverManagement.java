package Utilities;

import io.cucumber.java.After;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.concurrent.TimeUnit;

public class DriverManagement {

    private static WebDriver driver=null;
    public String DataFolderPath=System.getProperty("user.dir")+"/Data/";
    public String ChromePath=DataFolderPath+"binaries/chromedriver.exe";

    public WebDriver getDriver() {
        if(driver == null)
        {
            System.setProperty("webdriver.chrome.driver",ChromePath);
            driver=new ChromeDriver();
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
            driver.manage().window().maximize();

        }
        return driver;
    }

    @After
            public void tearDown()
    {
        driver.quit();
    }


}
