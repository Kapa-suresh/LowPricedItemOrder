Order Placement: We used selenium-java with cucumber to develope the solution in IntelliJ IDE.


Design highlights:
-----------------------------------
1. Followed Page Object Pattern, so created class file for each page. Those pages are in 'src/test/java/pages/'.
2. Implemented 'Singleton class' for driver in DriverManagment class('src/main/java/Utilities/').
3. Implemeneted 'CommonMethods'('src/main/java/Utilities/') class for reusable methods like findElement, EnterText, SelectValue. In future, we can add more methods which is useful across application 
4. Used try/catch block while asserting user sign in.


Run instructions:
------------------------------------
We can run this solution in two ways.
1. Using 'CucumberRunner' class. Right click in or on the file and choose 'Run CucumberRunner' option.
2. Directly from feature file. Right click on the scenario and choose 'Run Scenario: Place an order for low cost item and checkout' option.

Note:
-----------------------------
1. Added below properties in pom.xml to resolve compilation issues. As my java SDK version is 12, i used the version as 1.12. If you have different version please change this version before you run it.
<properties>
        <maven.compiler.source>1.12</maven.compiler.source>
        <maven.compiler.target>1.12</maven.compiler.target>
</properties>

2. Please add 'chromeDriver.exe' file under Binaries folder to run the solution. Gmail is not allowing attachment with exe files, so i removed it.

Included a video of testrun.